## <small>1.0.9 (2021-01-12)</small>

* config: .versionrc file added ([f594230](https://github.com/hayes0724/packer-blank-theme/commit/f594230))
* Bump ini from 1.3.5 to 1.3.7 ([aa7e199](https://github.com/hayes0724/packer-blank-theme/commit/aa7e199))
* Fix missing double quote in layout/theme.liquid ([db9cc6d](https://github.com/hayes0724/packer-blank-theme/commit/db9cc6d))
* Update name to use "theme_info" object ([9914c4b](https://github.com/hayes0724/packer-blank-theme/commit/9914c4b))



## <small>1.0.8 (2020-12-11)</small>

* chore: updated ignored files ([16a068b](https://github.com/hayes0724/packer-blank-theme/commit/16a068b))
* feat: body class set to template name and suffix ([f995581](https://github.com/hayes0724/packer-blank-theme/commit/f995581))
* docs: changelog added ([9130636](https://github.com/hayes0724/packer-blank-theme/commit/9130636))



## <small>1.0.7 (2020-10-05)</small>

* feat: new config files: `packer.config.js` and `packer.env.json` ([9864655](https://github.com/hayes0724/packer-blank-theme/commit/9864655))



## <small>1.0.6 (2020-09-30)</small>

* updated configurations and packages ([8471cf4](https://github.com/hayes0724/packer-blank-theme/commit/8471cf4))



## <small>1.0.5 (2020-09-28)</small>

* entrypoint templates ([789a7b5](https://github.com/hayes0724/packer-blank-theme/commit/789a7b5))



## <small>1.0.4 (2020-09-28)</small>

* .babelrc updated ([18b8d04](https://github.com/hayes0724/packer-blank-theme/commit/18b8d04))



## <small>1.0.3 (2020-09-28)</small>

* analyze command added ([229df21](https://github.com/hayes0724/packer-blank-theme/commit/229df21))



## <small>1.0.2 (2020-09-23)</small>

* Updated babel plugins ([3503673](https://github.com/hayes0724/packer-blank-theme/commit/3503673))



## <small>1.0.1 (2020-07-15)</small>

* fixed typo in scripts ([1915ce0](https://github.com/hayes0724/packer-blank-theme/commit/1915ce0))
* npm scripts updated ([39a18a3](https://github.com/hayes0724/packer-blank-theme/commit/39a18a3))
* updated package.json scripts ([6c84a79](https://github.com/hayes0724/packer-blank-theme/commit/6c84a79))
* webpack merge files ([f701484](https://github.com/hayes0724/packer-blank-theme/commit/f701484))



## 1.0.0 (2020-06-19)

* first commit ([a4c90f3](https://github.com/hayes0724/packer-blank-theme/commit/a4c90f3))
* Initial commit ([efffbf6](https://github.com/hayes0724/packer-blank-theme/commit/efffbf6))



