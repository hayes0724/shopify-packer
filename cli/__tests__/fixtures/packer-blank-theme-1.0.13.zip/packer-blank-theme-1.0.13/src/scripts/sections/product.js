/**
 * Product Section Script
 * ------------------------------------------------------------------------------
 * A file that contains scripts highly couple code to Product sections.
 *
 * @namespace product
 */
