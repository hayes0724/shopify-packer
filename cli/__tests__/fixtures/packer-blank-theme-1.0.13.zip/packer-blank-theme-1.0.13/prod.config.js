// Modify default webpack production config using this file
const mergeProd = {
  module: {
    rules: [

    ],
  }
}

module.exports = mergeProd
