// Modify default webpack dev config using this file
const mergeDev = {
  module: {
    rules: [

    ],
  }
}

module.exports = mergeDev
