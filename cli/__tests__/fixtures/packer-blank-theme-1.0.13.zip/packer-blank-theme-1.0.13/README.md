# Packer Blank Theme
An empty theme with the minimum requirements to upload to Shopify.
